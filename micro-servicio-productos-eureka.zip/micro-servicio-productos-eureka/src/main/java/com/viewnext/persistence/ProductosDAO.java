package com.viewnext.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.viewnext.models.Producto;

@RepositoryRestResource(collectionResourceRel = "PRODUCTOS", path = "productos")
public interface ProductosDAO extends JpaRepository<Producto, Long>{

	// Consultar todos los productos
	// http://localhost:8001/productos
	
	// Buscar un producto
	// http://localhost:8001/productos/3
}
