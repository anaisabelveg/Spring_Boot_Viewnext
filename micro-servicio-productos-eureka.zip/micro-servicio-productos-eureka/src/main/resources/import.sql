insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Monitor', 129.50);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Teclado', 45.50);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Raton', 29.95);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Impresora', 89.95);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Scanner', 200);