package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicioCarritoEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoEurekaApplication.class, args);
	}

}
