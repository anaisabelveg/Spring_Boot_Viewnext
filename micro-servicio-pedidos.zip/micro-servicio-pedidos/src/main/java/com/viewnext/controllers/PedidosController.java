package com.viewnext.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.models.Pedido;
import com.viewnext.services.IPedidoService;

@RestController
public class PedidosController {
	
	@Autowired
	@Qualifier(value = "pedidoServiceFeign")
	private IPedidoService service;
	
	// http://localhost:8002/buscar/2/cantidad/100
	@GetMapping("/buscar/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}

}
