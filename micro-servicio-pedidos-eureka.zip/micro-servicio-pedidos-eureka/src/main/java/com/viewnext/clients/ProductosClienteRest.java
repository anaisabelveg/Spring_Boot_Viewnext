package com.viewnext.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.viewnext.models.Producto;

// La peticion esta demasiado acoplada
//@FeignClient(url = "localhost:8001", name = "servicio-productos")
@FeignClient(name = "servicio-productos")
public interface ProductosClienteRest {
	
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id);

}
