package com.viewnext.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
@Primary   // Estoy dando prioridad a este bean para conectarse
public class PedidoServiceRestTemplate implements IPedidoService{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// cambiamos localhost:8001 por servicio-productos
		Producto producto = restTemplate.getForObject(
				"http://servicio-productos/buscar/{id}", Producto.class, id);
		return new Pedido(producto, cantidad);
	}

}
