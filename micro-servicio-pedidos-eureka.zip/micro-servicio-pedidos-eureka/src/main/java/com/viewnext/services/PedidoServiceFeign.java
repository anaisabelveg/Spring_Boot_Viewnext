package com.viewnext.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewnext.clients.ProductosClienteRest;
import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
public class PedidoServiceFeign implements IPedidoService{
	
	@Autowired
	private ProductosClienteRest clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		return new Pedido(producto, cantidad);
	}

}
